//Eu tentei fazer a tela 3 usando pop-up de Carrossel,
//fiquei mais de 2 horas tentando e não consegui,
//nunca tinha visto JavaScript antes.

//Eu sei fazer sem pop-up, mas dariam muitos arquivos HTML
//e eu queria tentar fazer diferente, no final acabou não
//dando tempo de fazer em em pop-up, nem em outra pagina HTML, infelizmente.